const AssistantV2 = require('ibm-watson/assistant/v2');
const { IamAuthenticator } = require('ibm-watson/auth');
const LanguageTranslatorV3 = require('ibm-watson/language-translator/v3');

function main(params) {

    // Watson Assistant (WA) credentials
    let wa_apikey = params.wa_apikey;
    let wa_url = params.wa_url;
    let wa_version = params.wa_version;
    let assistantId = params.assistantId;

    let lt_apikey = params.lt_apikey;
    let lt_url = params.lt_url;
    let lt_version = params.lt_version;

    // variables for debugging
    let originalInput = "";
    let translatedInput = "";
    let originalOutput = "";
    let translatedOutput = "";

    // instantiates LT and WA authenticators and objects
    const authenticatorWA = new IamAuthenticator({ apikey: wa_apikey });
    const authenticatorLT = new IamAuthenticator({ apikey: lt_apikey });

    const assistant = new AssistantV2({
        version: wa_version,
        authenticator: authenticatorWA,
        url: wa_url,
    });

    const languageTranslator = new LanguageTranslatorV3({
        version: lt_version,
        authenticator: authenticatorLT,
        url: lt_url,
    });

    // assign variables from input parameters, passed from Watson Assistant
    session_id = params.session_id; // ? params.session_id : '';
    userUtter = params.user_utterance;
    originalInput = userUtter;
    language = params.language;

    console.log("Original input: ", originalInput);

    // LT parameters
    const translateParams = {
        text: userUtter,
        source: language,
        target: "en",
    };

    if (session_id == '0' && language != "en") {
        return new Promise((resolve, reject) => {
            console.log("Will need to create a session")

            assistant.createSession({
                assistantId: assistantId
            }).then(res => {
                session_id = res.result.session_id;
                return languageTranslator.translate(translateParams);
            }).then(function (translationResult) {

                // receive english translation from LT service
                let englishTransl = translationResult.result.translations[0].translation;
                console.log("English input: ", englishTransl);
                translatedInput = englishTransl;

                // send english translated input to WA
                return assistant.message({
                    assistantId: assistantId,
                    sessionId: session_id,
                    input: {
                        'message_type': 'text',
                        'text': englishTransl
                    }
                });
            }).then(function (res) {
                // receive english translated response from WA
                let englishResp = res.result.output.generic[0].text;
                console.log("English output: ", englishResp);
                originalOutput = englishResp;

                // parameters for converting response to user language
                const translateParams = {
                    text: res.result.output.generic[0].text,
                    source: "en",
                    target: language,
                };

                return languageTranslator.translate(translateParams);

            }).then(function (translationResult) {
                // receive bot response in user language
                console.log("Output translation: ", translationResult.result.translations[0].translation);
                translatedOutput = translationResult.result.translations[0].translation;

                // returns translations at each step to the chatbot
                resolve({ "message": translationResult.result.translations[0].translation, "originalInput": originalInput, "translatedInput": translatedInput, "originalOutput": originalOutput, "translatedOutput": translatedOutput, "session_id": session_id });
            }).catch(function (err) {

                // if an error occurs, return the error
                reject({ "error": err });
                console.log("****error: ", err);
            });
        })
    } else if (session_id != '0' && language != "en") {
        return new Promise((resolve, reject) => {
            // if no session ID needs to be created
            languageTranslator.translate(translateParams).then(function (translationResult) {

                // receive english translation from LT service
                let englishTransl = translationResult.result.translations[0].translation;
                console.log("English input: ", englishTransl);
                translatedInput = englishTransl;

                // send english translated input to WA
                return assistant.message({
                    assistantId: assistantId,
                    sessionId: session_id,
                    input: {
                        'message_type': 'text',
                        'text': englishTransl
                    }
                });
            }).then(function (res) {
                ;
                // receive english translated response from WA
                let englishResp = res.result.output.generic[0].text;
                console.log("English output: ", englishResp);
                originalOutput = englishResp;

                // parameters for converting response to user language
                const translateParams = {
                    text: res.result.output.generic[0].text,
                    source: "en",
                    target: language,
                };

                return languageTranslator.translate(translateParams);

            }).then(function (translationResult) {
                // receive bot response in user language
                console.log("Output translation: ", translationResult.result.translations[0].translation);
                translatedOutput = translationResult;

                // returns translations at each step to the chatbot
                resolve({ "message": translationResult.result.translations[0].translation, "originalInput": originalInput, "translatedInput": translatedInput, "originalOutput": originalOutput, "translatedOutput": translatedOutput, "session_id": session_id });
            }).catch(function (err) {
                // if an error occurs, return the error
                reject({ "error": err });
                console.log("****error: ", err);
            });
        })
    } else if (session_id == '0' && language == "en") {
        console.log("0 session id and english language");
        return new Promise((resolve, reject) => {
            assistant.createSession({
                assistantId: assistantId
            }).then(res => {
                session_id = res.result.session_id;
                return assistant.message({
                    assistantId: assistantId,
                    sessionId: session_id,
                    input: {
                        'message_type': 'text',
                        'text': originalInput
                    }
                }).then(function (res) {
                    let assistantResponse = res.result.output.generic[0].text;
                    console.log("assistantResponse: ", assistantResponse);
                    console.log("session_id: ", session_id);
                    resolve({ "message": assistantResponse, "session_id": session_id });
                }).catch(function (err) {
                    reject({ "error": err });
                    console.log("****error: ", err);
                });
            })
        });
    } else if (session_id != '0' && language == "en") {
        return new Promise((resolve, reject) => {
            return assistant.message({
                assistantId: assistantId,
                sessionId: session_id,
                input: {
                    'message_type': 'text',
                    'text': originalInput
                }
            }).then(function (res) {
                let assistantResponse = res.result.output.generic[0].text;
                console.log("English output here: ", assistantResponse);
                resolve({ "message": assistantResponse, "session_id": session_id });
            }).catch(function (err) {
                reject({ "error": err });
                console.log("****error: ", err);
            });
        });
    }
}

exports.main = main;

// This is for local testing
// main({session_id: "0", user_utterance: "welcome_welcome", language: "en", assistantId: "90bc7c04-6cd6-439b-b1ed-c849855d88f8", wa_apikey: "9G1SSSXXrRtV-k5-gn2pCVGNjKu5hAxoeZSlGbOaZ1Jj"});
